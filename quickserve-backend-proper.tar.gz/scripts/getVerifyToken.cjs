require('dotenv').config();
const mongoose = require('mongoose');

const uri = process.env.MONGO_URI;
if (!uri) {
  console.error('MONGO_URI missing in environment');
  process.exit(2);
}

const email = process.argv[2];
if (!email) {
  console.error('Usage: node getVerifyToken.cjs user@example.com');
  process.exit(2);
}

async function run() {
  await mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });
  const users = mongoose.connection.collection('users');
  const user = await users.findOne({ email: email.toLowerCase() });
  if (!user) {
    console.error('User not found');
    process.exit(3);
  }
  const token = user.verifyToken;
  if (!token) {
    console.error('No verifyToken available for this user');
    process.exit(4);
  }
  const base = process.env.APP_BASE_URL || 'http://192.168.136.104:5000';
  const url = `${base}/auth/verify?token=${encodeURIComponent(token)}`;
  console.log(url);
  process.exit(0);
}

run().catch((e) => { console.error(e); process.exit(1); });
