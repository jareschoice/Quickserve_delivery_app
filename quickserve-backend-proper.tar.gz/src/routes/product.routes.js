import express from "express";
import Product from "../models/Product.js";
import Vendor from "../models/Vendor.js";
import { requireAuth, requireRole } from "../middleware/auth.js";

const router = express.Router();

// Vendor add product
router.post("/", requireAuth, requireRole(["vendor"]), async (req, res) => {
  try {
    const v = await Vendor.findOne({ owner: req.user.id });
    if (!v) return res.status(400).json({ error: "Vendor profile not found" });
    const { name, description, price, imageUrl, category } = req.body;
    const p = await Product.create({ vendor: v._id, name, description, price, imageUrl, category });
    res.json({ product: p });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Vendor update product
router.put("/:id", requireAuth, requireRole(["vendor"]), async (req, res) => {
  try {
    const v = await Vendor.findOne({ owner: req.user.id });
    const p = await Product.findOne({ _id: req.params.id, vendor: v._id });
    if (!p) return res.status(404).json({ error: "Not found" });
    Object.assign(p, req.body);
    await p.save();
    res.json({ product: p });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Vendor delete product
router.delete("/:id", requireAuth, requireRole(["vendor"]), async (req, res) => {
  try {
    const v = await Vendor.findOne({ owner: req.user.id });
    await Product.deleteOne({ _id: req.params.id, vendor: v._id });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Public list products (with optional vendor filter)
router.get("/", async (req, res) => {
  const { vendorId } = req.query;
  const q = vendorId ? { vendor: vendorId } : {};
  const items = await Product.find(q).sort({ createdAt: -1 });
  res.json({ items });
});

export default router;
