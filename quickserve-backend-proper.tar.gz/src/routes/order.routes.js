import express from "express";
import Order from "../models/Order.js";
import Vendor from "../models/Vendor.js";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { calculateDeliveryFee, quickserveFee } from "../utils/fare.js";
import { createQrPayload, generateQrPngBase64 } from "../utils/qr.js";
import { notifyAdmin } from "../utils/notify.js";

const router = express.Router();

// Create order (customer)
router.post("/", requireAuth, requireRole(["customer"]), async (req, res) => {
  try {
    const { vendorId, items, distanceKm = 0, customerAddress, vendorAddress } = req.body;
    const vendor = await Vendor.findById(vendorId);
    if (!vendor) return res.status(400).json({ error: "Vendor not found" });

    const subtotal = items.reduce((sum, it) => sum + Number(it.price) * Number(it.qty), 0);
    const deliveryFee = calculateDeliveryFee(distanceKm);
    const qsFee = quickserveFee();
    const total = subtotal + deliveryFee + qsFee;

    const order = await Order.create({
      customer: req.user.id,
      vendor: vendor._id,
      items,
      subtotal,
      deliveryFee,
      quickserveFee: qsFee,
      total,
      customerAddress,
      vendorAddress,
      status: "pending"
    });

    res.json({ order });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Vendor accept/reject
router.post("/:id/accept", requireAuth, requireRole(["vendor"]), async (req, res) => {
  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ error: "Not found" });
  order.status = "accepted";
  await order.save();
  res.json({ order });
});

router.post("/:id/reject", requireAuth, requireRole(["vendor"]), async (req, res) => {
  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ error: "Not found" });
  order.status = "cancelled";
  await order.save();
  res.json({ order });
});

// Vendor update status (preparing / waiting_pickup)
router.post("/:id/status", requireAuth, requireRole(["vendor"]), async (req, res) => {
  const { status } = req.body;
  const valid = ["preparing", "waiting_pickup"];
  if (!valid.includes(status)) return res.status(400).json({ error: "Invalid status" });
  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ error: "Not found" });
  order.status = status;
  await order.save();
  res.json({ order });
});

// Rider assignment (simple manual endpoint for now)
router.post("/:id/assign-rider", requireAuth, requireRole(["vendor", "admin"]), async (req, res) => {
  const { riderId } = req.body;
  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ error: "Not found" });
  order.rider = riderId;
  order.status = "assigned";

  // Create QR for delivery confirmation
  const { token, data } = createQrPayload(order._id.toString());
  order.qrToken = token;
  order.qrTokenExpiresAt = new Date(Date.now() + 1000 * 60 * 60); // 1 hour
  await order.save();
  const qrBase64 = await generateQrPngBase64(data);

  res.json({ order, qrBase64 }); // Rider app shows this QR
});

// Rider marks in_transit
router.post("/:id/in-transit", requireAuth, requireRole(["rider"]), async (req, res) => {
  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ error: "Not found" });
  order.status = "in_transit";
  await order.save();
  res.json({ order });
});

// Consumer scans QR and confirms delivery
router.post("/:id/confirm-delivery", requireAuth, requireRole(["customer"]), async (req, res) => {
  const { token } = req.body;
  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ error: "Not found" });
  if (order.status === "delivered") return res.json({ order }); // idempotent
  if (!order.qrToken || order.qrToken !== String(token)) return res.status(400).json({ error: "Invalid QR token" });
  if (order.qrTokenExpiresAt && order.qrTokenExpiresAt < new Date()) return res.status(400).json({ error: "QR expired" });

  order.status = "delivered";
  await order.save();

  // Notify admin
  await notifyAdmin(
    "Order Delivered ✔️",
    `<p>Order <b>${order._id}</b> has been delivered.</p>
     <p>QuickServe fee: ₦${order.quickserveFee}.</p>`
  );

  res.json({ order });
});

// Get my orders (for any role)
router.get("/mine", requireAuth, async (req, res) => {
  const role = req.user.role;
  const id = req.user.id;
  let q = {};
  if (role === "customer") q.customer = id;
  if (role === "vendor") q.vendor = id; // NOTE: could map vendor owner->vendor
  if (role === "rider") q.rider = id;
  const items = await Order.find(q).sort({ createdAt: -1 });
  res.json({ items });
});

export default router;
