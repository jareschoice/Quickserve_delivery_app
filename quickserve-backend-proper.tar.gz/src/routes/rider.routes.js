import express from "express";
import { requireAuth, requireRole } from "../middleware/auth.js";
import Order from "../models/Order.js";

const router = express.Router();

// Rider fetch assigned orders
router.get("/assigned", requireAuth, requireRole(["rider"]), async (req, res) => {
  const items = await Order.find({ rider: req.user.id, status: { $in: ["assigned", "in_transit"] } }).sort({ createdAt: -1 });
  res.json({ items });
});

export default router;
