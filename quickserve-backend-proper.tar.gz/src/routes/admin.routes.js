import express from "express";
import { requireAuth, requireRole } from "../middleware/auth.js";
import Order from "../models/Order.js";
import Vendor from "../models/Vendor.js";
import User from "../models/User.js";

const router = express.Router();

router.get("/stats", requireAuth, requireRole(["admin"]), async (req, res) => {
  const [orders, vendors, riders, customers] = await Promise.all([
    Order.countDocuments({}),
    Vendor.countDocuments({}),
    User.countDocuments({ role: "rider" }),
    User.countDocuments({ role: "customer" }),
  ]);
  res.json({ orders, vendors, riders, customers });
});

router.get("/orders", requireAuth, requireRole(["admin"]), async (req, res) => {
  const items = await Order.find({}).sort({ createdAt: -1 }).limit(200);
  res.json({ items });
});

export default router;
