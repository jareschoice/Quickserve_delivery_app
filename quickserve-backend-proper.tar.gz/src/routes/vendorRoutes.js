import { Router } from 'express'
import { authRequired } from '../middleware/auth.js'

const router = Router()

router.get('/me', authRequired('vendor'), (req, res) => {
  res.json({
    vendor: req.user.vendor || {},
    user: { id: req.user._id, fullName: req.user.fullName }
  })
})

export default router