import mongoose from 'mongoose'

const OrderSchema = new mongoose.Schema({
  consumerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  vendorId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  riderId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  items: [{
    name: String,
    price: Number,
    qty: Number
  }],
  subtotal: Number,
  deliveryFee: Number,
  platformFee: Number,
  total: Number,
  status: { 
    type: String, 
    enum: ['placed','accepted','preparing','ready','dispatch_requested','assigned','in_transit','delivered','cancelled'],
    default: 'placed'
  },
  qrToken: String, // expected at delivery
  distanceKm: Number,
  deliveryAddress: String,
  notes: String,
  paystackReference: String
}, { timestamps: true })

export default mongoose.model('Order', OrderSchema)
