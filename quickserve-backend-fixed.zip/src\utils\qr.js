import QRCode from "qrcode";
import { v4 as uuidv4 } from "uuid";

export const createQrPayload = (orderId) => {
  const token = uuidv4(); // short-lived token
  const payload = { orderId, token };
  return { token, data: JSON.stringify(payload) };
};

export const generateQrPngBase64 = async (data) => {
  const pngDataUrl = await QRCode.toDataURL(data);
  // strip prefix 'data:image/png;base64,'
  const base64 = pngDataUrl.split(",")[1];
  return base64;
};
