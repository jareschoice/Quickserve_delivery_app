import express from "express";
import Vendor from "../models/Vendor.js";
import { requireAuth, requireRole } from "../middleware/auth.js";

const router = express.Router();

// Create/Update vendor profile
router.post("/profile", requireAuth, requireRole(["vendor"]), async (req, res) => {
  try {
    const owner = req.user.id;
    const { businessName, description, logoUrl, address, category, location } = req.body;
    let v = await Vendor.findOne({ owner });
    if (!v) {
      v = await Vendor.create({ owner, businessName, description, logoUrl, address, category, location });
    } else {
      Object.assign(v, { businessName, description, logoUrl, address, category, location });
      await v.save();
    }
    res.json({ vendor: v });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Get my vendor profile
router.get("/me", requireAuth, requireRole(["vendor"]), async (req, res) => {
  const v = await Vendor.findOne({ owner: req.user.id });
  res.json({ vendor: v });
});

export default router;
