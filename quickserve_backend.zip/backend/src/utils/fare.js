export const calculateDeliveryFee = (distanceKm = 0) => {
  const base = 300; // base price (you can tune)
  const perKm = 120; // per km
  return Math.round(base + perKm * Math.max(0, distanceKm));
};

export const quickserveFee = () => 50; // constant for now
