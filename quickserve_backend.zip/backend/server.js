import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import morgan from 'morgan'
import bodyParser from 'body-parser'
import './src/config/db.js'

import authRoutes from './src/routes/authRoutes.js'
import vendorRoutes from './src/routes/vendorRoutes.js'
import riderRoutes from './src/routes/riderRoutes.js'
import orderRoutes from './src/routes/orderRoutes.js'
import paymentRoutes from './src/routes/paymentRoutes.js'
import emailRoutes from './src/routes/emailRoutes.js'
import { createServer } from 'http'
import { Server as IOServer } from 'socket.io'

const app = express()
const httpServer = createServer(app)
app.use(helmet())
app.use(cors())
app.use(bodyParser.json({ limit: '2mb' }))
app.use(bodyParser.urlencoded({ extended: true }))
app.use(morgan('tiny'))

// 🚀 DEVELOPMENT: Serve static files for testing
app.use(express.static('public'))

app.get('/', (req, res) => {
  res.json({ ok: true, service: 'QuickServe API', time: new Date().toISOString() })
})

app.use('/auth', authRoutes)
app.use('/vendors', vendorRoutes)
app.use('/riders', riderRoutes)
app.use('/orders', orderRoutes)
app.use('/payments', paymentRoutes)
app.use('/api/email', emailRoutes)

// 404 + error handler
app.use((req, res) => res.status(404).json({ error: 'Not found' }))
app.use((err, req, res, next) => {
  console.error('ERR:', err)
  res.status(500).json({ error: 'Internal server error', detail: err.message })
})

const io = new IOServer(httpServer, {
  cors: { origin: '*' }
})

// attach io to app locals so controllers can emit events
app.locals.io = io

const PORT = process.env.PORT || 5000
httpServer.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 QuickServe API running on http://0.0.0.0:${PORT}`)
});

io.on('connection', (socket) => {
  console.log('Socket connected', socket.id)
  socket.on('disconnect', () => console.log('Socket disconnected', socket.id))
})
