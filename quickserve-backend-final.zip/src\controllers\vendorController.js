import Vendor from '../models/Vendor.js'
import User from '../models/User.js'
export async function createVendor(req,res){ const {storeName,userId}=req.body; const u=await User.findById(userId); if(!u) return res.status(404).json({error:'User not found'}); const v=await Vendor.create({user:u._id,storeName}); res.json(v) }
