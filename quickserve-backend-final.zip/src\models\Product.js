import mongoose from 'mongoose'
const s=new mongoose.Schema({vendor:{type:mongoose.Schema.Types.ObjectId,ref:'Vendor',required:true},name:{type:String,required:true},price:{type:Number,required:true},imageUrl:String,description:String},{timestamps:true})
export default mongoose.model('Product',s)
