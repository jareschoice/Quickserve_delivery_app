import express from "express";
import crypto from "crypto";
import Order from "../models/Order.js";

const router = express.Router();

router.post("/webhook", express.json({ type: "*/*" }), async (req, res) => {
  const secret = process.env.PAYSTACK_SECRET_KEY;
  const signature = req.headers["x-paystack-signature"];
  const hash = crypto.createHmac("sha512", secret).update(JSON.stringify(req.body)).digest("hex");
  if (hash !== signature) return res.status(401).send("Invalid signature");

  const event = req.body;
  try {
    if (event.event === "charge.success") {
      const reference = event.data.reference;
      const orderId = event.data.metadata?.orderId;
      const o = await Order.findById(orderId);
      if (o) {
        o.payment = {
          reference,
          paid: true,
          channel: event.data.channel,
          verifiedAt: new Date(),
        };
        await o.save();
      }
    }
    res.sendStatus(200);
  } catch (e) {
    console.error("Webhook error:", e.message);
    res.sendStatus(500);
  }
});

export default router;
